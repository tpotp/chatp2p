export const config = { runtime: 'edge' };

const ALLOWED_ORIGIN = 'https://chatp2p-bice.vercel.app';
const SECRET = process.env.CHAT_SECRET || 'cambia-esto-por-algo-random-en-vercel';

// HMAC-SHA256 con Web Crypto (disponible en Edge Runtime)
async function sign(payload) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(SECRET),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payload));
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export default async function handler(req) {
  const origin = req.headers.get('origin') || '';

  // 🔒 Rechazar cualquier origen que no sea el tuyo
  if (origin !== ALLOWED_ORIGIN) {
    return new Response(JSON.stringify({ error: 'Forbidden' }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Token con expiración de 1 hora
  const expires = Math.floor(Date.now() / 1000) + 3600;
  const payload = `${expires}`;
  const signature = await sign(payload);
  const token = `${expires}.${signature}`;

  return new Response(JSON.stringify({ token }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
      'Cache-Control': 'no-store'
    }
  });
}
